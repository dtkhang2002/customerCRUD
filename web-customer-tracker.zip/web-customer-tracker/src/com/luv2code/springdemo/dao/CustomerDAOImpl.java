package com.luv2code.springdemo.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.luv2code.springdemo.entity.Customer;
import com.luv2code.springdemo.util.SortUtils;

@Repository
public class CustomerDAOImpl implements CustomerDAO {

	// need to inject the session factory
	@Autowired
	private SessionFactory sessionFactory;
			
	@Override
	public List<Customer> getCustomers() {
		
		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
				
		// create a query sort by lastName
		Query<Customer> theQuery = 
				currentSession.createQuery("from Customer order by last_name", Customer.class);
		
		// execute query and get result list
		List<Customer> customers = theQuery.getResultList();
				
		// return the results		
		return customers;
	}

	@Override
	public void saveCustomer(Customer theCustomer) {
		// get current session
		Session currentSession = sessionFactory.getCurrentSession();
		// save to the db .. finally
		currentSession.saveOrUpdate(theCustomer);
	}

	@Override
	public Customer getCustomer(int id) {
		// get the current session
		Session currentSession = sessionFactory.getCurrentSession();
		// retrieve from db using id
		Customer customer = currentSession.get(Customer.class, id);
		return customer;
	}

	@Override
	public void deleteCustomer(int id) {
		// get current session
		Session currentSession = sessionFactory.getCurrentSession();
		// delete the customer with query using id
		@SuppressWarnings("rawtypes")
		Query query = currentSession.createQuery("delete from Customer where id =: theCustomerId");
		query.setParameter("theCustomerId", id);
		query.executeUpdate();
		
	}

	@Override
	public List<Customer> searchCustomers(String name) {
		// get the current session
		Session currentSession = sessionFactory.getCurrentSession();
		@SuppressWarnings("rawtypes")
		Query query = null;
		if(name != null && name.trim().length() > 0) {
			query = currentSession.createQuery("from Customer where lower(firstName) like :theName or lower(lastName) like :theName", Customer.class);
			query.setParameter("theName", "%" + name.toLowerCase() + "%");
		}else {
			query = currentSession.createQuery("from Customer order by last_name", Customer.class);
		}
		// execute query
		@SuppressWarnings("unchecked")
		List<Customer> customers = query.getResultList();
		return customers;
	}

	@Override
	public List<Customer> getCustomerss(int theSortField) {
		// get the current session
		Session currentSession = sessionFactory.getCurrentSession();
		String theFieldName = null;
		switch (theSortField) {
			case SortUtils.ID: 
				theFieldName = "id";
				break;
		
			case SortUtils.FIRST_NAME:
				theFieldName = "firstName";
				break;
				
			case SortUtils.LAST_NAME:
				theFieldName = "lastName";
				break;
			
			case SortUtils.COMPANY:
				theFieldName = "company";
				break;
			default:
				theFieldName = "lastName";
			}
		Query<Customer> theQuery = 
				currentSession.createQuery("from Customer order by " + theFieldName, Customer.class);
		
		// execute query and get result list
				List<Customer> customers = theQuery.getResultList();
						
				// return the results		
				return customers;
		}
}

