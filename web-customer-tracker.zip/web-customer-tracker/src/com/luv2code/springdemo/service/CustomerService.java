package com.luv2code.springdemo.service;

import java.util.List;

import com.luv2code.springdemo.entity.Customer;

public interface CustomerService {
	// select * from table
	public List<Customer> getCustomer();
	// insert into table
	public void saveCustomer(Customer theCustomer);
	// select id from table
	public Customer getCustomers(int id);
	// delete from table where id
	public void deleteCustomer(int id);
	// search
	public List<Customer> searchCustomer(String name);
	// leverage
	public List<Customer> getCustomerss(int theSortField);
}
